#include <mpi.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char** argv) {

    MPI_Barrier(MPI_COMM_WORLD);   // ERROR: MPI not initialized yet

    MPI_Init(&argc, &argv);

    MPI_Barrier(MPI_COMM_WORLD);   // OK but useless

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    printf("Rank %d: Hello World\n", rank);
    fflush(stdout);

    usleep(150000 * (rank + 1));

    if (rank == 0) {
        MPI_Barrier(MPI_COMM_WORLD);   // DEADLOCK (only rank 0 calls)
    }

    MPI_Barrier(MPI_COMM_WORLD);       // Correct synchronization

    char msg[128] = {0};
    if (rank == 0) {
        snprintf(msg, sizeof(msg), "Root %d", rank);
    }

    MPI_Bcast(msg, 128, MPI_CHAR, 0, MPI_COMM_WORLD);

    MPI_Barrier(MPI_COMM_WORLD);       // OK: ensures messages printed together

    printf("Rank %d: got \"%s\"\n", rank, msg);
    fflush(stdout);

    MPI_Finalize();

    MPI_Barrier(MPI_COMM_WORLD);       // ERROR: MPI is finalized

    return 0;
}

