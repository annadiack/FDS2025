#!/bin/bash
#SBATCH --job-name=task4
#SBATCH --partition=xeon
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --hint=nomultithread
#SBATCH --time=00:02:00

module load OpenMPI/5.0.3-GCC-13.3.0

mpirun ./task4

