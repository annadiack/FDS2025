#include <mpi.h>
#include <stdio.h>

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size, len;
    char hostname[MPI_MAX_PROCESSOR_NAME];

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Get_processor_name(hostname, &len);

    char msg[256];
    MPI_Request req;

    if (rank == 0) {
        snprintf(msg, sizeof(msg),
                 "Hello World from rank %d on node %s",
                 rank, hostname);

        for (int r = 1; r < size; r++) {
            MPI_Isend(msg, 256, MPI_CHAR, r, 0, MPI_COMM_WORLD, &req);
            MPI_Wait(&req, MPI_STATUS_IGNORE);
        }
    } else {
        MPI_Irecv(msg, 256, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &req);
        MPI_Wait(&req, MPI_STATUS_IGNORE);

        printf("Rank %d on node %s received: %s\n", rank, hostname, msg);
    }

    MPI_Finalize();
    return 0;
}

